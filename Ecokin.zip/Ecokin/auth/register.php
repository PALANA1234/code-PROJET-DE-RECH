<?php
require_once("../config/database.php");
require_once("../config/session.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nom = trim($_POST["nom"]);
    $prenom = trim($_POST["prenom"]);
    $email = trim($_POST["email"]);
    $telephone = trim($_POST["telephone"]);
    $adresse = trim($_POST["adresse"]);
    $commune = trim($_POST["commune"]);
    $role = $_POST["role"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm_password"];

    // Vérification des champs
    if (
        empty($nom) ||
        empty($prenom) ||
        empty($email) ||
        empty($telephone) ||
        empty($adresse) ||
        empty($commune) ||
        empty($role) ||
        empty($password) ||
        empty($confirmPassword)
    ) {

        $message = '<div class="alert alert-danger">
                        Tous les champs sont obligatoires.
                    </div>';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = '<div class="alert alert-danger">
                        Adresse e-mail invalide.
                    </div>';

    } elseif ($password != $confirmPassword) {

        $message = '<div class="alert alert-danger">
                        Les mots de passe ne correspondent pas.
                    </div>';

    } else {

        // Vérifier si l'utilisateur existe
        $req = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $req->execute([$email]);

        if ($req->rowCount() > 0) {

            $message = '<div class="alert alert-warning">
                            Cet e-mail existe déjà.
                        </div>';

        } else {

            // Chiffrement du mot de passe
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            // Insertion
            $insert = $pdo->prepare("
                INSERT INTO users
                (
                    role_id,
                    nom,
                    prenom,
                    email,
                    telephone,
                    mot_de_passe,
                    adresse,
                    commune,
                    statut
                )

                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    'actif'
                )
            ");

            if ($insert->execute([
                $role,
                $nom,
                $prenom,
                $email,
                $telephone,
                $passwordHash,
                $adresse,
                $commune
            ])) {

                $message = '<div class="alert alert-success">
                                Compte créé avec succès.
                            </div>';

            } else {

                $message = '<div class="alert alert-danger">
                                Une erreur est survenue.
                            </div>';
            }

        }

    }

}
?>

<!DOCTYPE html>
<html lang="fr">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Inscription - EcoKin</title>

<link rel="stylesheet" href="../assets/css/bootstrap.min.css">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-8">

<div class="card shadow">

<div class="card-header bg-success text-white">

<h3 class="text-center">
Créer un compte EcoKin
</h3>

</div>

<div class="card-body">

<?= $message; ?>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">

<label>Nom</label>

<input
type="text"
name="nom"
class="form-control"
required>

</div>

<div class="col-md-6 mb-3">

<label>Prénom</label>

<input
type="text"
name="prenom"
class="form-control"
required>

</div>

</div>

<div class="mb-3">

<label>Email</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Téléphone</label>

<input
type="text"
name="telephone"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Adresse</label>

<input
type="text"
name="adresse"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Commune</label>

<input
type="text"
name="commune"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Rôle</label>

<select
name="role"
class="form-select"
required>

<option value="">Choisir...</option>

<option value="2">Citoyen</option>

<option value="3">ONG</option>

<option value="4">Entreprise</option>

<option value="5">École</option>

<option value="6">Autorité</option>

</select>

</div>

<div class="row">

<div class="col-md-6 mb-3">

<label>Mot de passe</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<div class="col-md-6 mb-3">

<label>Confirmer le mot de passe</label>

<input
type="password"
name="confirm_password"
class="form-control"
required>

</div>

</div>

<div class="d-grid">

<button
type="submit"
class="btn btn-success">

Créer mon compte

</button>

</div>

</form>

<hr>

<p class="text-center">

Déjà inscrit ?

<a href="login.php">

Se connecter

</a>

</p>

</div>

</div>

</div>

</div>

</div>

<script src="../assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>