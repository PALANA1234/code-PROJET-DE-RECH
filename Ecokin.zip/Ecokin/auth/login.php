<?php
require_once("../config/redirect.php");
require_once("../config/database.php");
require_once("../config/session.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if (empty($email) || empty($password)) {

        $message = '<div class="alert alert-danger">
                        Veuillez remplir tous les champs.
                    </div>';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = '<div class="alert alert-danger">
                        Adresse e-mail invalide.
                    </div>';

    } else {

        // Récupérer l'utilisateur
        $sql = "SELECT * FROM users WHERE email = ? LIMIT 1";
        $req = $pdo->prepare($sql);
        $req->execute([$email]);

        if ($req->rowCount() == 1) {

            $user = $req->fetch(PDO::FETCH_ASSOC);

            // Vérifier si le compte est actif
            if ($user["statut"] != "actif") {

                $message = '<div class="alert alert-warning">
                                Votre compte est désactivé.
                            </div>';

            } elseif (password_verify($password, $user["mot_de_passe"])) {

                // Création des variables de session
                $_SESSION["id"] = $user["id"];
                $_SESSION["nom"] = $user["nom"];
                $_SESSION["prenom"] = $user["prenom"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["role_id"] = $user["role_id"];
                $_SESSION["photo"] = $user["photo"];
                $_SESSION["points"] = $user["points"];

                redirectUser($user["role_id"]);

            } else {

                $message = '<div class="alert alert-danger">
                                Mot de passe incorrect.
                            </div>';

            }

        } else {

            $message = '<div class="alert alert-danger">
                            Aucun compte trouvé avec cette adresse e-mail.
                        </div>';

        }

    }

}
?>

<!DOCTYPE html>

<html lang="fr">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Connexion - EcoKin</title>

<link rel="stylesheet" href="../assets/css/bootstrap.min.css">

</head>

<body class="bg-light">

<div class="container">

<div class="row justify-content-center mt-5">

<div class="col-md-5">

<div class="card shadow">

<div class="card-header bg-success text-white">

<h3 class="text-center">

Connexion EcoKin

</h3>

</div>
<?php

if(isset($_GET["logout"])){

echo '

<div class="alert alert-success">

Vous êtes maintenant déconnecté.

</div>

';

}

?>

<div class="card-body">

<?= $message ?>

<form method="POST">

<div class="mb-3">

<label>Email</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Mot de passe</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<div class="d-grid">

<button
type="submit"
class="btn btn-success">

Se connecter

</button>

</div>

</form>

<hr>

<p class="text-center">

Pas encore inscrit ?

<a href="register.php">

Créer un compte

</a>

</p>

</div>

</div>

</div>

</div>

</div>

<script src="../assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>