<?php

/**
 * Redirige un utilisateur selon son rôle.
 *
 * Roles :
 * 1 = Administrateur
 * 2 = Citoyen
 * 3 = ONG
 * 4 = Entreprise
 * 5 = École
 * 6 = Autorité
 */

function redirectUser($role_id)
{
    switch ($role_id) {

        case 1:
            header("Location: ../admin/index.php");
            exit();

        case 2:
            header("Location: ../citoyen/index.php");
            exit();

        case 3:
            header("Location: ../ong/index.php");
            exit();

        case 4:
            header("Location: ../entreprise/index.php");
            exit();

        case 5:
            header("Location: ../ecole/index.php");
            exit();

        case 6:
            header("Location: ../autorite/index.php");
            exit();

        default:

            session_destroy();

            header("Location: login.php?error=role");

            exit();
    }
}