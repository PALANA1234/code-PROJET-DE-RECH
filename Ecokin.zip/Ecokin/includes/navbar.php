<nav class="navbar navbar-expand-lg navbar-dark bg-success">

<div class="container">

<a class="navbar-brand" href="#">

🌍 EcoKin

</a>

</div>
<a href="../auth/logout.php"
   class="btn btn-danger">

<i class="bi bi-box-arrow-right"></i>

Déconnexion

</a>

</nav>
