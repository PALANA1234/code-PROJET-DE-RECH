<?php

define("SITE_NAME","EcoKin");

define("BASE_URL","http://localhost/EcoKin/");